# Consumer Internals

> Planned learning area. This folder is intentionally a landing page; detailed notes will be added as the topics are studied.

Polling, fetching, offset commits, delivery semantics, rebalancing, and consumer crash recovery.

See [[syllabus]] for the complete checklist and current learning order.
