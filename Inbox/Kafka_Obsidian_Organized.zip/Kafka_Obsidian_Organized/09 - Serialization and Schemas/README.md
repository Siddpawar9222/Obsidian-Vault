# Serialization and Schemas

> Planned learning area. This folder is intentionally a landing page; detailed notes will be added as the topics are studied.

String/JSON serialization, Java DTOs, custom serializers, schema evolution, Avro, and Schema Registry.

See [[syllabus]] for the complete checklist and current learning order.
