# Apache Kafka — Master Syllabus and Progress Tracker

> Goal: Build a strong conceptual understanding of Kafka, then apply it in Java/Spring Boot microservices. This is a backend-developer learning syllabus, not an exhaustive Kafka administrator certification syllabus.

## Learning status

- [x] = covered in existing notes or previous learning discussions
- [~] = currently learning / partially covered
- [ ] = pending
- [P] = practical implementation

## Module A — Kafka Foundations and Architecture

- [x] What Apache Kafka is
- [x] Why Kafka is needed
- [x] Synchronous REST communication vs asynchronous event-driven communication
- [x] Kafka use cases and benefits
- [x] Event, record/message, key, value, headers, timestamp
- [x] Topic, partition, offset, broker, cluster
- [x] Producer and consumer roles
- [x] Kafka architecture and end-to-end message flow
- [x] Pull model vs push model
- [x] Sequential disk I/O
- [x] Operating system page cache
- [x] Zero-copy (`sendfile`)
- [x] Batching and compression (architecture-level introduction)

**Primary notes:** [[001-Introduction_and_Problem_Statement]], [[002-Core_Terminologies]], [[003-Kafka_Architecture_and_Internals]]

## Module B — Topics, Partitions, Routing, and Ordering

- [x] Topic structure and topic configuration
- [x] Partition as an ordered, append-only log
- [x] Why partitions provide parallelism and scalability
- [x] Partition vs broker vs topic
- [x] Single-broker vs multi-broker topology
- [x] Producer partition-selection strategies
- [x] Key-based partitioning and hash-based routing
- [x] Default partitioner and sticky partitioning
- [x] Explicit partition selection
- [x] Choosing a business partition key (`orderId`, `accountId`, etc.)
- [x] Ordering guarantee within a partition
- [x] Why Kafka does not guarantee global ordering
- [x] Effect of increasing partition count on key-to-partition mapping

**Primary notes:** [[004-Topics_and_Partitions]], [[005-Producer_Partitioning_and_Ordering]]

## Module C — Consumer Groups and Introductory Offset Concepts

- [x] Consumer workflow and pull-based consumption
- [x] Consumer groups and their purpose
- [x] Partition assignment within a consumer group
- [x] One partition is assigned to at most one consumer in a group at a time
- [x] More consumers than partitions
- [x] Fewer consumers than partitions
- [x] Multiple independent consumer groups reading the same topic
- [x] Consumer scaling and load distribution
- [x] Introductory offset tracking and commits
- [ ] Consumer polling internals and fetch configuration
- [ ] Automatic vs manual offset commit in depth
- [ ] `commitSync()` vs `commitAsync()`
- [ ] Consumer position vs committed offset
- [ ] Offset reset (`earliest`, `latest`, `none`)
- [ ] Reprocessing and restart behavior

**Primary notes:** [[006-Consumers_and_Consumer_Groups]]

## Module D — Replication, Durability, and Fault Tolerance

- [x] Partitioning vs replication
- [x] Replica, leader, and follower
- [x] Replication factor and broker placement
- [x] ISR (In-Sync Replicas)
- [x] Follower replication and synchronization
- [x] Out-of-sync replicas and ISR removal
- [x] Leader failover
- [x] Clean vs unclean leader election
- [x] High Watermark (HW)
- [x] Log End Offset (LEO)
- [x] Leader epoch
- [x] Eligible Leader Replicas (ELR)
- [x] Last Known ELR
- [~] Producer acknowledgements (`acks=0`, `acks=1`, `acks=all`)
- [~] `min.insync.replicas`
- [ ] How acknowledgements, ISR, and minimum ISR work together
- [ ] Durability trade-offs and failure scenarios

**Primary notes:** [[007-Replication_and_Fault_Tolerance]]

## Module E — KRaft and Cluster Metadata Consensus

- [x] Why Kafka moved away from ZooKeeper
- [x] Cluster metadata vs business records
- [x] KRaft architecture
- [x] Raft consensus fundamentals
- [x] Controller and broker roles
- [x] Active controller and controller quorum
- [x] `__cluster_metadata` metadata log
- [x] Metadata replication across controllers
- [x] Topic creation and metadata update flow
- [x] Raft leader vs partition leader
- [x] Majority/quorum calculation
- [x] Controller failure and leader election
- [x] Broker failure vs controller failure
- [x] Epochs and metadata snapshots
- [x] Combined mode vs dedicated mode
- [x] Cluster ID, node ID, and controller quorum voters

**Primary note:** [[008-KRaft_and_Cluster_Consensus]]

## Module F — Producer Internals and Reliability

- [ ] Producer workflow, metadata lookup, and routing to partition leader
- [ ] Record accumulator
- [ ] Producer batching and `batch.size`
- [ ] `linger.ms`
- [ ] Producer buffer memory and `buffer.memory`
- [ ] Compression (`gzip`, `snappy`, `lz4`, `zstd`) — purpose and trade-offs
- [~] Producer acknowledgements (`acks=0`, `acks=1`, `acks=all`)
- [~] `min.insync.replicas`
- [ ] Producer retries and retry configuration
- [ ] Idempotent producer
- [ ] Producer sequence numbers and duplicate prevention
- [ ] Delivery timeout and request timeout
- [ ] Producer delivery failures and callbacks

## Module G — Consumer Internals, Offsets, and Delivery Semantics

- [ ] `poll()` lifecycle and consumer polling loop
- [ ] Fetching records from brokers
- [ ] `max.poll.records`
- [ ] `fetch.min.bytes`
- [ ] `fetch.max.wait.ms`
- [ ] Automatic offset commit
- [ ] Manual offset commit
- [ ] Synchronous vs asynchronous commits
- [ ] Offset reset strategies
- [ ] At-most-once delivery
- [ ] At-least-once delivery
- [ ] Exactly-once semantics (conceptual distinction)
- [ ] How commit timing affects delivery semantics
- [ ] Duplicate processing scenarios
- [ ] Consumer rebalancing and why it happens
- [ ] Eager vs cooperative/incremental rebalancing
- [ ] Partition assignment strategies
- [ ] Heartbeats, session timeout, and `max.poll.interval.ms`
- [ ] What happens when a consumer crashes
- [ ] Recovery from last committed offset
- [ ] Static membership (introduction)

## Module H — Serialization, Event Design, and Schemas

- [ ] Serialization and deserialization
- [ ] Kafka `Serializer` and `Deserializer` interfaces
- [ ] String and byte-array serialization
- [ ] JSON serialization and deserialization
- [ ] Message key, value, headers, and timestamp
- [ ] Java DTO event design
- [ ] Custom serializers and deserializers
- [ ] Poison pill messages
- [ ] Schema evolution
- [ ] Schema Registry (introduction)
- [ ] Avro (introduction)
- [ ] Backward, forward, and full compatibility

## Module I — Reliability and Error Handling

- [ ] Producer-side retry behavior
- [ ] Consumer processing failures
- [ ] Retry strategies and retry topics
- [ ] Backoff: fixed and exponential
- [ ] Dead Letter Topic (DLT)
- [ ] Dead Letter Publishing
- [ ] Poison pill handling
- [ ] Duplicate message handling
- [ ] Idempotent consumer design
- [ ] Database deduplication using event/message IDs
- [ ] Database transaction vs Kafka offset commit challenge
- [ ] Kafka transactions
- [ ] Transactional producer and transactional ID
- [ ] Atomic writes across Kafka partitions
- [ ] `read_committed` vs `read_uncommitted`
- [ ] Kafka exactly-once processing overview
- [ ] Kafka transactions vs database transactions

## Module J — Kafka Storage, Retention, and Compaction

- [ ] Kafka log structure
- [ ] Log segments and active segment
- [ ] Segment rolling
- [ ] Offset index and timestamp index
- [ ] Retention policy
- [ ] Time-based retention (`retention.ms`)
- [ ] Size-based retention (`retention.bytes`)
- [ ] Delete cleanup policy
- [ ] Log compaction
- [ ] `cleanup.policy=delete` vs `compact`
- [ ] Tombstone records
- [ ] How Kafka removes old segments and compacted records

## Module K — Spring Boot and Spring Kafka

- [ ] Add Spring Kafka dependency
- [ ] Configure bootstrap servers
- [ ] Producer and consumer configuration
- [ ] Create topics with `KafkaAdmin` / `NewTopic`
- [ ] Publish with `KafkaTemplate`
- [ ] Consume with `@KafkaListener`
- [ ] Send keyed messages and JSON DTOs
- [ ] Configure consumer groups
- [ ] Configure listener concurrency
- [ ] Manual acknowledgement
- [ ] Producer callbacks and asynchronous sends
- [ ] Error handling with `DefaultErrorHandler`
- [ ] Retry and backoff configuration
- [ ] `DeadLetterPublishingRecoverer`
- [ ] `@RetryableTopic` (where appropriate)
- [ ] Idempotent consumer with database deduplication
- [ ] Kafka transactions in Spring
- [ ] Batch listeners
- [ ] Graceful shutdown and operational configuration

**Practical guide:** [[06 - Spring Boot Integration/012-HandsOn_SpringBoot_Step_By_Step_Guide]]

## Module L — Performance, Monitoring, and Operations

- [ ] Producer throughput and latency trade-offs
- [ ] Batching and compression tuning
- [ ] Consumer concurrency and throughput
- [ ] Consumer lag: what it means and how to monitor it
- [ ] Broker/topic/partition metrics
- [ ] Spring Boot Actuator and Prometheus
- [ ] Throughput benchmarking
- [ ] CLI-based troubleshooting
- [ ] Operational health checks and graceful recovery

**Existing command reference:** [[05 - Operations and Revision/010-Kafka_CLI_Commands]]

## Module M — Kafka Ecosystem and Comparisons

- [ ] Kafka vs RabbitMQ
- [ ] When to choose Kafka vs a traditional message broker
- [ ] Kafka Connect (introduction)
- [ ] Source and sink connectors (introduction)
- [ ] Kafka Streams (introduction)
- [ ] Stream processing use cases

## Module N — End-to-End Practical Project

Build an event-driven order management system:

```text
Order Service
    |
    | OrderCreated event
    v
  Kafka
    |
    +------> Inventory Service
    |
    +------> Payment Service
    |
    +------> Notification Service
```

- [P] Run a multi-broker KRaft cluster locally using Docker Compose
- [P] Build Spring Boot producer and consumer services
- [P] Verify key-based partitioning and ordering
- [P] Run multiple consumer instances and observe assignments/rebalances
- [P] Use multiple consumer groups for independent processing
- [P] Exchange JSON DTO events
- [P] Implement retries and DLT
- [P] Implement idempotent consumer processing
- [P] Configure acknowledgements and offsets
- [P] Experiment with Kafka transactions
- [P] Monitor consumer lag and basic metrics

## Existing notes and quick references

- [[01 - Foundations/001-Introduction_and_Problem_Statement]]
- [[01 - Foundations/002-Core_Terminologies]]
- [[01 - Foundations/003-Kafka_Architecture_and_Internals]]
- [[02 - Topics and Partitioning/004-Topics_and_Partitions]]
- [[02 - Topics and Partitioning/005-Producer_Partitioning_and_Ordering]]
- [[03 - Consumers and Consumer Groups/006-Consumers_and_Consumer_Groups]]
- [[04 - Replication and KRaft/007-Replication_and_Fault_Tolerance]]
- [[04 - Replication and KRaft/008-KRaft_and_Cluster_Consensus]]
- [[05 - Operations and Revision/009-End_to_End_Industrial_Example]]
- [[05 - Operations and Revision/010-Kafka_CLI_Commands]]
- [[05 - Operations and Revision/011-Quick_Revision_and_Interview_Guide]]
- [[06 - Spring Boot Integration/012-HandsOn_SpringBoot_Step_By_Step_Guide]]
- [[00 - Start Here/Original_Syllabus]]
