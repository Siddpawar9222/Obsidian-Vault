# Producer Internals

> Planned learning area. This folder is intentionally a landing page; detailed notes will be added as the topics are studied.

Producer workflow, batching, acknowledgements, retries, idempotence, and delivery guarantees.

See [[syllabus]] for the complete checklist and current learning order.
