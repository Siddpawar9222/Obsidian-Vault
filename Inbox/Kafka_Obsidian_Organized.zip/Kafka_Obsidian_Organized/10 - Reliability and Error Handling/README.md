# Reliability and Error Handling

> Planned learning area. This folder is intentionally a landing page; detailed notes will be added as the topics are studied.

Producer retries, consumer retries, backoff, DLT, poison pills, idempotent consumers, and Kafka transactions.

See [[syllabus]] for the complete checklist and current learning order.
