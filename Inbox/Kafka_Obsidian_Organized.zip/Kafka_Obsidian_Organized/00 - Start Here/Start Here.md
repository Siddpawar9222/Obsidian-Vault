# Kafka Learning Vault

> A structured Obsidian vault for learning Apache Kafka from fundamentals to practical Spring Boot integration.

## How to use this vault

- Start with [[syllabus]] for the master learning roadmap and progress tracker.
- Use the folders in sequence, but revisit earlier notes whenever a later concept depends on them.
- Existing learning notes have been moved into topic-based folders. Their original Markdown content, examples, diagrams, code blocks, commands, and explanations have been preserved.
- [[Original_Syllabus]] contains the syllabus that was included in the uploaded ZIP, preserved separately.
- The original note filenames are retained so existing Obsidian wikilinks can continue resolving by note name.

## Learning style

Each new topic should explain:

- What the concept is.
- Why Kafka needs it.
- How it works internally, step by step.
- A real-world example.
- How it is used in Java/Spring Boot microservices.
- Important configurations, trade-offs, failure scenarios, and interview points.

## Folder map

| Folder | Purpose |
|---|---|
| `01 - Foundations` | Kafka's purpose, terminology, architecture, and internal message flow |
| `02 - Topics and Partitioning` | Topics, partitions, producer routing, keys, and ordering |
| `03 - Consumers and Consumer Groups` | Consumer roles, groups, assignment, scaling, and introductory offsets |
| `04 - Replication and KRaft` | Replication, ISR, failover, metadata, controllers, and Raft quorum |
| `05 - Operations and Revision` | End-to-end architecture, CLI commands, and interview revision |
| `06 - Spring Boot Integration` | Hands-on Spring Kafka implementation |
| `07 - Producer Internals` | Notes to be developed: producer workflow, batching, acknowledgements, retries, idempotence |
| `08 - Consumer Internals` | Notes to be developed: polling, commits, delivery semantics, rebalancing, crash recovery |
| `09 - Serialization and Schemas` | Notes to be developed: serializers, JSON, schema evolution, Avro, Schema Registry |
| `10 - Reliability and Error Handling` | Notes to be developed: retries, DLT, idempotent consumers, Kafka transactions |
| `11 - Storage and Retention` | Notes to be developed: log segments, indexes, retention, compaction, tombstones |
| `12 - Performance and Operations` | Notes to be developed: tuning, monitoring, consumer lag, production operations |
| `13 - Kafka Ecosystem` | Notes to be developed: Kafka vs RabbitMQ, Kafka Connect, Kafka Streams |

## Preservation note

The 12 original topic notes and the original syllabus from the uploaded ZIP have been retained. The source note bodies have not been shortened or rewritten during this restructuring. New navigation and roadmap notes have been added around them.
