# Source Preservation Manifest

The following original Markdown files were copied from the uploaded ZIP without editing their note bodies:

- `001-Introduction_and_Problem_Statement.md` → `01 - Foundations/`
- `002-Core_Terminologies.md` → `01 - Foundations/`
- `003-Kafka_Architecture_and_Internals.md` → `01 - Foundations/`
- `004-Topics_and_Partitions.md` → `02 - Topics and Partitioning/`
- `005-Producer_Partitioning_and_Ordering.md` → `02 - Topics and Partitioning/`
- `006-Consumers_and_Consumer_Groups.md` → `03 - Consumers and Consumer Groups/`
- `007-Replication_and_Fault_Tolerance.md` → `04 - Replication and KRaft/`
- `008-KRaft_and_Cluster_Consensus.md` → `04 - Replication and KRaft/`
- `009-End_to_End_Industrial_Example.md` → `05 - Operations and Revision/`
- `010-Kafka_CLI_Commands.md` → `05 - Operations and Revision/`
- `011-Quick_Revision_and_Interview_Guide.md` → `05 - Operations and Revision/`
- `012-HandsOn_SpringBoot_Step_By_Step_Guide.md` → `06 - Spring Boot Integration/`
- `syllabus.md` → `00 - Start Here/Original_Syllabus.md` (original syllabus retained)

New files added: `00 - Start Here/Start Here.md`, the new root `syllabus.md`, and landing pages for future learning areas.

The original note bodies were not shortened, summarized, or deleted. Only their folder locations changed.